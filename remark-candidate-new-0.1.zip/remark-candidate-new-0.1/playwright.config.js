// @ts-check
import { defineConfig } from '@playwright/test';

export default defineConfig({

  testDir: './tests',

  timeout: 120000,

  fullyParallel: true,

  forbidOnly: !!process.env.CI,

  retries: process.env.CI ? 2 : 0,

  workers: process.env.CI ? 1 : undefined,

  reporter: [['html', { open: 'never' }]],

  use: {

    trace: 'on-first-retry',

    storageState: 'auth.json',

    // storageState: '.auth/user.json',

    permissions: [],

    viewport: {
      width: 1920,
      height: 1080,
    },

    launchOptions: {
      executablePath:
        'C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe',

      args: [
        '--start-maximized',
        '--window-position=0,0',
        '--window-size=1920,1080',
      ],
    },
  },

});
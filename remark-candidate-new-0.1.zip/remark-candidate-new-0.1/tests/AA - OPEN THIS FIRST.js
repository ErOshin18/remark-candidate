// Applied , Job Search , Saved Jobs 
export const  jobtitle = 'Ducting Worker HVAC Help';

// Profile Instagram URL
export const profileinstaupdate = `www. ${jobtitle} .com`;


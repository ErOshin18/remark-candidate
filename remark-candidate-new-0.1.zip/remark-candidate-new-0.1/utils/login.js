// import { expect } from '@playwright/test';

// export async function login(page) {

//   // import { expect } from '@playwright/test';

//   await page.goto('https://remarkhr.com');
  

//   await page.getByRole('button', { name: 'Close app download card' }).click();
//   await page.getByRole('button', { name: 'Close modal' }).click();
//   await page.getByRole('button', { name: 'Reject all cookies' }).click();

//   await expect(page.getByRole('link', { name: 'Log In' })).toBeVisible();

//   await page.getByRole('link', { name: 'Log In' }).click();

//   await page.waitForLoadState('networkidle');

//   await page.getByRole('textbox', { name: 'Email or mobile number' })
//     .fill('7777777777');

//   await page.getByRole('button', { name: 'Login with OTP' }).click();

//   // await page.waitForLoadState('networkidle');


//   await page.locator('input[maxlength="1"]').nth(0).fill('9');
//   await page.locator('input[maxlength="1"]').nth(1).fill('9');
//   await page.locator('input[maxlength="1"]').nth(2).fill('9');
//   await page.locator('input[maxlength="1"]').nth(3).fill('9');
  
//   await page.waitForTimeout(10);

//   await page.waitForLoadState('networkidle');

//   await page.getByRole('button', { name: 'Verify OTP' }).click();
//   await page.waitForLoadState('networkidle');

//   console.log(
//   await page.evaluate(() => {
//     return Object.fromEntries(
//       Object.entries(localStorage)
//     );
//   })
// );
// await page.context().storageState({ path: 'auth.json' });


//   // await page.waitForTimeout(5000);
//   // await page.locator('#remark-logo').getByRole('link', { name: 'remark logo' }).click();
//   // await page.getByRole('button', { name: 'Close app download card' }).click();
//   // await page.getByRole('button', { name: 'Close modal' }).click();
//   // await page.getByRole('button', { name: 'Reject all cookies' }).click();

// }